// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = false // True For Public // False For Self
global.owner = ['6285198622453'] //Own Number
global.developer = "ZynzzDev" //Dev Name
global.botname = "Thunder Storm" //Bot Name
global.version = "1.0.0" //Version Bot

//Sticker Setiings
global.packname = "Sticker By Zynzz" //Pack Name 
global.author = "Zynzz" // Author

//Social Media Settings
global.ytube = ""
global.ttok = ""
global.igram = ""
global.chtele = ""
global.tgram = "t.me/Zynzz_Thunder"
global.limitCount = 1,

//Bug Name Settings
global.bak = {
Ios: " 𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�? ",
Andro: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?", 
Crash: " ̶𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�? ̶",
Freeze: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?",
Ui: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})