module.exports = {
  BOT_TOKEN: "bot_token_anda_disini"
};